import java.util.Scanner;
public class entry {

	private static Scanner r;

	public static void main(String[] args) 
	{
		String[][] Degrees  = {
				{"����" , "85"},
				{"���" , "75"},
				{"����" , "65"},
				{"���" , "99"},
				{"����" , "46"},
				{"����" , "44"},
				{"����� " , "59"},
				{"����" , "100"}
		        };
	
		r = new Scanner(System.in);
		
		System.out.print("Enter the ID number: ");
		String D = r.next();
		
		for(int i = 0; i< Degrees.length; i++)
			if(D.equals(Degrees[i][0]))
				
				
				
				
		System.out.println(Degrees[i][1]);
		
		
		
		
		
		
		
		

	}

}
